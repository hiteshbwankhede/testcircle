﻿# Interview questions

**Question 1.** Have you done Web Scrapping? If Yes, then tell me how would you find out, it's legal or not?

**Question 2.** For creating text or appending texts we use "w+" and "a+", what is the use of "+" sign in this?

**Question 3.** Do you convert words into numbers like 6 = six?

**Question 4.** Why it is important to remove punctuation from sentence?

**Question 5.** What is regex? What is the use of regex?