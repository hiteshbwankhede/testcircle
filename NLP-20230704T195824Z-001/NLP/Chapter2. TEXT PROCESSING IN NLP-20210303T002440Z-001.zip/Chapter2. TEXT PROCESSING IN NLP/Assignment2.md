﻿# Assignment 1

### Important Notes to follow for doing the assignmnets

1. Use Markdown to create your assignmnets. Use <a href="https://markdownmonster.west-wind.com/" target="_blank">Markdown_Monster</a> or <a href="https://typora.io/" target="_blank">Typora</a> to decorate your documents. 
2. There should be pictures attached to the needed documnets can be internet souce or self made.
3. Mention all the important formula and equations needed as per the topic
4. Upload all the assignments chapterwise/sectionwise.
5. Submit all your assignmnets before deadlines.
6. Write the answers below the specific questions.

## Chapter 2

**Question 1.** Write a python program to find out the words after '@' from the below sentences with the use of regex.

"xyz@gmail.com",
"abc@yahoo.com",
"xyz@hotmail.com",
"abc@ineuron.ai",
"xyz@outlook.com"

**Question 2.** Write a python program with the use of regex to take out the word "New" from the following sentence.

["New Delhi is the capital of India"]

**Question 3.** Create one python program in which you have to lowercase the sentence first and than delete digits from the following sentence.

"In India, 184 people got affected with Corona virus and 4 are died."

**Question 4.** Do stemming, lemmatization and tokenization from the following sentence.

"I hope that, when I have built up my savings, I will be able to travel to Hawai."

**Question 5.** Create one python program from the following sentence.

"I love NLP, not you"

output : ['I', 'l', 'N', 'n', 'y']