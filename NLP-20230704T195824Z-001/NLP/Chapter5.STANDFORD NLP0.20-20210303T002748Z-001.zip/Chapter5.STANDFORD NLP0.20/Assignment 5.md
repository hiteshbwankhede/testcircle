﻿# Assignment 5

### Important Notes to follow for doing the assignmnets

1. Use Markdown to create your assignmnets. Use <a href="https://markdownmonster.west-wind.com/" target="_blank">Markdown_Monster</a> or <a href="https://typora.io/" target="_blank">Typora</a> to decorate your documents. 
2. There should be pictures attached to the needed documnets can be internet souce or self made.
3. Mention all the important formula and equations needed as per the topic
4. Upload all the assignments chapterwise/sectionwise.
5. Submit all your assignmnets before deadlines.
6. Write the answers below the specific questions.

**Question 1.** What are the differences in between NLTK and Stanfordnlp? What things we can easily do in NLTK but not in Stanfordnlp and vice versa?

**Question 2.** Which NLP library is best for dependency parsing?And Explain,Why that library is best?

**Question 3.** Is Documents and sentence are same?

**Question 4.** What is the use of Multi-word tokens property in Stanfordnlp?