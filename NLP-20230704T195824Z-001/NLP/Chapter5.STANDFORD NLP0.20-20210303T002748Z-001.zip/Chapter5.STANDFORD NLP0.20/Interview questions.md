﻿# Interview questions

**Question 1.** What are the differences in between NLTK and Stanfordnlp? What things we can easily do in NLTK but not in Stanfordnlp and vice versa?

**Question 2.** Which NLP library is best for dependency parsing?And Explain,Why that library is best?

**Question 3.** Is Documents and sentence are same?

**Question 4.** What is the use of Multi-word tokens property in Stanfordnlp?